# Wealth ETL Project

This project demonstrates an **ETL (Extract, Transform, Load)** pipeline for a Wealth Advisor transitioning into **Data Analytics**.

## Features
- Extracts sample client, account, holding, and transaction data from CSVs
- Transforms into client wealth summaries
- Loads into a SQLite database
- Generates a CSV report and a balance chart visualization

## Usage
```bash
pip install -r requirements.txt
python etl_pipeline.py
```

Outputs will be saved in the `build/` folder:
- `wealth.db` (SQLite database)
- `wealth_report.csv` (summary report)
- `balances_chart.png` (visualization)

## Requirements
- Python 3.8+
- pandas
- matplotlib
- sqlite3 (built-in)
