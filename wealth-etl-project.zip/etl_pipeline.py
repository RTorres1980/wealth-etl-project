import pandas as pd
import sqlite3
import matplotlib.pyplot as plt
import os

# Paths
DATA_DIR = 'data'
BUILD_DIR = 'build'
DB_PATH = os.path.join(BUILD_DIR, 'wealth.db')
REPORT_PATH = os.path.join(BUILD_DIR, 'wealth_report.csv')

# Ensure build directory exists
os.makedirs(BUILD_DIR, exist_ok=True)

# Extract: Load CSVs
clients = pd.read_csv(os.path.join(DATA_DIR, 'clients.csv'))
accounts = pd.read_csv(os.path.join(DATA_DIR, 'accounts.csv'))
holdings = pd.read_csv(os.path.join(DATA_DIR, 'holdings.csv'))
transactions = pd.read_csv(os.path.join(DATA_DIR, 'transactions.csv'))

# Transform: Example aggregation
wealth_summary = accounts.groupby('client_id')['balance'].sum().reset_index()
wealth_summary = wealth_summary.merge(clients, on='client_id')

# Load: Save into SQLite database
conn = sqlite3.connect(DB_PATH)
clients.to_sql('clients', conn, if_exists='replace', index=False)
accounts.to_sql('accounts', conn, if_exists='replace', index=False)
holdings.to_sql('holdings', conn, if_exists='replace', index=False)
transactions.to_sql('transactions', conn, if_exists='replace', index=False)
wealth_summary.to_sql('wealth_summary', conn, if_exists='replace', index=False)
conn.close()

# Save report as CSV
wealth_summary.to_csv(REPORT_PATH, index=False)

# Visualization: Bar chart of client balances
plt.figure(figsize=(8,5))
plt.bar(wealth_summary['name'], wealth_summary['balance'])
plt.title('Client Total Balances')
plt.ylabel('Balance ($)')
plt.savefig(os.path.join(BUILD_DIR, 'balances_chart.png'))
plt.close()

print('ETL completed. Outputs saved in build/.')
